package com.whizenx.amath.Game.Engine;

public class Validate {

}
