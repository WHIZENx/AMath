package com.example.myapplication.Game;

public class Setting {

    static int num = 15;
    static int selectNum = 8;

    public static int getNum() {
        return num;
    }

    public static void setNum(int num) {
        Setting.num = num;
    }

    public static int getSelectNum() {
        return selectNum;
    }

    public static void setSelectNum(int selectNum) {
        Setting.selectNum = selectNum;
    }
}
