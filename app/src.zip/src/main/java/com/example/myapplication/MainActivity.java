package com.example.myapplication;

import static com.example.myapplication.Game.Engine.Game.start;
import static com.example.myapplication.Game.Engine.initMotion.initMotionObj;
import static com.example.myapplication.Game.Engine.initObj.initAllObj;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start(MainActivity.this, 1);
    }
}